export default {
  BASE_URL: 'https://yamatrack-api.dedicateddevelopers.us/api',
  
  YAMATRACKCREDS: 'YAMATRACKCREDS',
  ROLE:'ROLE',
  ID: 'ID',
  EMAIL:'EMAIL',

  SYNCWISE_BASE_URL: 'https://dev-api-dna.igolf.com/rest/action',
  APPLICATION_KEY: 'BDTwGkxf2g8sETx',
  APP_SECRET_KEY: 'KNHBexQgL0vSMq7SySBhLthlUuIqq0',
  USER_NAME: 'ytservicebackend',
  USER_SECRET_KEY: '3K9amXGSqmCnrx00LnERAkc5Vuk-F2qI9C528sOw',
  

};
