export default {
  BASE_URL: 'https://celebrity-production.solutionsfinder.co.uk/grocley/public/api',
  
  
  

};
