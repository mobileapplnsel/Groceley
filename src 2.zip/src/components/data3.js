import { ICONS } from "../themes/Themes";

const data3 = [
    {   
        img3: ICONS.milk,

        body3: "50% OFF on purchase of 4 Amul Milk",
    },
   
    {
        img3: ICONS.cornflakes,
        body3: "25% community discount available on Kellog's cereal",
    },
    {   
        img3: ICONS.logo1,
        body3: "Membership discounts of 5% available on all products",
    },
]
export default data3;