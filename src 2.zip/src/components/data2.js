import { ICONS } from "../themes/Themes";

const data2 = [
    {
        body: 'Get discount coupons on purchases above 1000 INR'
    },
   
    {
        body: 'Monthly 25% OFF if 10 breakfast items are bought together'
    },
    {
        body: '200 coins will be credited if membership is taken'
    },
]
export default data2;