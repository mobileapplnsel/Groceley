import { ICONS } from "../themes/Themes";

const data = [
    {
        img: ICONS.carouselone,
      

    },
   
    {
        img: ICONS.carouseltwo,
       
    },
    {
        img: ICONS.carouselone,
       
    },
]
export default data;