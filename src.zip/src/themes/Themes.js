export const IMAGES = {
   logo: require('../assets/images/Logo.png'),
};

export const ICONS = {
  // back: require('../assets/icons/Back.png'),
  // cross: require('../assets/icons/Cross.png'),
  // menu: require('../assets/icons/Menu.png'),
  // plus: require('../assets/icons/Plus.png'),
  // barcodeblack: require('../assets/icons/Barcodeblack.png'),
  // edit: require('../assets/icons/Edit.png'),
  // delete: require('../assets/icons/Delete.png'),
  // deletered: require('../assets/icons/Deletered.png'),
  // help: require('../assets/icons/Help.png'),
  // cars: require('../assets/icons/Cars.png'),
  // logout: require('../assets/icons/Logout.png'),
  // number4: require('../assets/icons/Number4.png'),
  // admintools: require('../assets/icons/Admintools.png'),
  // rightarrow: require('../assets/icons/Rightarrow.png'),
  // leftarrow: require('../assets/icons/Leftarrow.png'),
  // show: require('../assets/icons/Show.png'),
  // hide: require('../assets/icons/Hide.png'),
  // helpmenu: require('../assets/icons/Helpmenu.png'),
  // usericon: require('../assets/icons/User_icon.png'),
  // buttonplus: require('../assets/icons/Primary_button.png'),
  // rectangle: require('../assets/icons/Rectangle.png'),
  // rectanglegreen: require('../assets/icons/Rectanglegreen.png'),
  // barcodescanner: require('../assets/icons/Barcodescanner.png'),
  // flashon: require('../assets/icons/Flash_on.png'),
  // flashoff: require('../assets/icons/Flash_off.png'),
  // barcodebox: require('../assets/icons/Barcode_box.png'),
  // barcodeline: require('../assets/icons/Barcode_line.png'),
  // downchevron: require('../assets/icons/Downchevron.png'),
   bed: require('../assets/icons/bed.png'),
};

export const FONTS = {
  // OpenSansRegular: 'OpenSans-Regular',
  // OpenSansSemiBold: 'OpenSans-SemiBold',
  // OpenSansBold: 'OpenSans-Bold',
  // OpenSansExtraBold: 'OpenSans-ExtraBold',
  // TrumpGothicProMedium: 'TrumpGothicPro-Medium',
  // TrumpGothicPro: 'TrumpGothicPro',
  // TrebuchetMS: 'Trebuchet MS',
  // TrebuchetMSBold: 'Trebuchet MS Bold',
   PlayfairDisplayBlack: 'PlayfairDisplay-Black',
   RubikBold: 'Rubik-Bold'
};

export const COLORS = {
  // black: '#292929',
  // lightBlack: '#292929',
  // yamahaRed: '#E50E21',
  // white: '#FFFFFF',
  // grey: '#ECECEC',
  // darkgrey: '#7D7D7D',
  // lightgrey: '#E2E2E2',
  // green: '#5BBE6A',
};
